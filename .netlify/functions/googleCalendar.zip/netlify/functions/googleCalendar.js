var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/googleCalendar.js
var googleCalendar_exports = {};
__export(googleCalendar_exports, {
  createGoogleCalendarEvent: () => createGoogleCalendarEvent,
  deleteGoogleCalendarEventByBookingId: () => deleteGoogleCalendarEventByBookingId,
  getGoogleCalendarBusyRanges: () => getGoogleCalendarBusyRanges,
  updateGoogleCalendarEventByBookingId: () => updateGoogleCalendarEventByBookingId
});
module.exports = __toCommonJS(googleCalendar_exports);
var import_node_crypto = __toESM(require("crypto"), 1);
var saProject = process.env.FIREBASE_PROJECT_ID || "handymanserviceadmin";
var GOOGLE_SA_EMAIL = process.env.GOOGLE_SA_EMAIL || `herehandyman-booking@${saProject}.iam.gserviceaccount.com`;
var GOOGLE_SA_PRIVATE_KEY = (process.env.GOOGLE_SA_PRIVATE_KEY || "").replace(/\\n/g, "\n");
var GOOGLE_CALENDAR_ID = process.env.GOOGLE_CALENDAR_ID || "davi65@gmail.com";
async function getAccessToken() {
  if (!GOOGLE_SA_EMAIL || !GOOGLE_SA_PRIVATE_KEY) {
    return null;
  }
  const now = Math.floor(Date.now() / 1e3);
  const header = { alg: "RS256", typ: "JWT" };
  const claimSet = {
    iss: GOOGLE_SA_EMAIL,
    scope: "https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/calendar.events",
    aud: "https://oauth2.googleapis.com/token",
    exp: now + 3600,
    iat: now
  };
  const b64Header = Buffer.from(JSON.stringify(header)).toString("base64url");
  const b64ClaimSet = Buffer.from(JSON.stringify(claimSet)).toString("base64url");
  const unsignedJwt = `${b64Header}.${b64ClaimSet}`;
  const signer = import_node_crypto.default.createSign("RSA-SHA256");
  signer.update(unsignedJwt);
  const signature = signer.sign(GOOGLE_SA_PRIVATE_KEY, "base64url");
  const jwt = `${unsignedJwt}.${signature}`;
  const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: jwt
    })
  });
  if (!tokenRes.ok) {
    const errorText = await tokenRes.text();
    console.error("Google OAuth token error:", errorText);
    return null;
  }
  const tokenData = await tokenRes.json();
  return tokenData.access_token;
}
async function getGoogleCalendarBusyRanges(dayStartIso, dayEndIso) {
  try {
    const token = await getAccessToken();
    if (!token || !GOOGLE_CALENDAR_ID) return [];
    const res = await fetch("https://www.googleapis.com/calendar/v3/freeBusy", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        timeMin: dayStartIso,
        timeMax: dayEndIso,
        timeZone: "America/New_York",
        items: [{ id: GOOGLE_CALENDAR_ID }]
      })
    });
    if (!res.ok) {
      console.error("Google FreeBusy error:", await res.text());
      return [];
    }
    const data = await res.json();
    const calendarData = data.calendars && data.calendars[GOOGLE_CALENDAR_ID];
    const busyList = calendarData ? calendarData.busy || [] : [];
    return busyList.map((item) => ({
      start: new Date(item.start).getTime(),
      end: new Date(item.end).getTime()
    }));
  } catch (err) {
    console.error("Error fetching Google Calendar busy ranges:", err);
    return [];
  }
}
async function createGoogleCalendarEvent({
  bookingId,
  startIso,
  endIso,
  serviceName,
  customerName,
  customerPhone,
  customerEmail,
  customerAddress,
  zip,
  notes
}) {
  try {
    const token = await getAccessToken();
    if (!token || !GOOGLE_CALENDAR_ID) return null;
    const eventPayload = {
      summary: `\u{1F528} [${bookingId}] ${serviceName} - ${customerName}`,
      location: `${customerAddress}, ZIP ${zip}`,
      description: `APPOINTMENT CONFIRMED FROM WEBSITE

Booking ID: ${bookingId}
Customer: ${customerName}
Phone: ${customerPhone}
Email: ${customerEmail || "Not provided"}
Address: ${customerAddress}, ZIP ${zip}
Service: ${serviceName}
Notes: ${notes || "None"}`,
      start: { dateTime: startIso, timeZone: "America/New_York" },
      end: { dateTime: endIso, timeZone: "America/New_York" },
      reminders: {
        useDefault: false,
        overrides: [
          { method: "popup", minutes: 120 },
          { method: "popup", minutes: 30 }
        ]
      }
    };
    const res = await fetch(`https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(GOOGLE_CALENDAR_ID)}/events`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(eventPayload)
    });
    if (!res.ok) {
      console.error("Google Calendar Event Insert Error:", await res.text());
      return null;
    }
    const eventData = await res.json();
    return eventData.id;
  } catch (err) {
    console.error("Error creating Google Calendar event:", err);
    return null;
  }
}
async function deleteGoogleCalendarEventByBookingId(bookingId, email) {
  try {
    const token = await getAccessToken();
    if (!token || !GOOGLE_CALENDAR_ID) return false;
    const searchRes = await fetch(
      `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(GOOGLE_CALENDAR_ID)}/events?q=${encodeURIComponent(bookingId)}`,
      {
        headers: { "Authorization": `Bearer ${token}` }
      }
    );
    if (!searchRes.ok) {
      console.error("Google Calendar Event Search Error:", await searchRes.text());
      return false;
    }
    const searchData = await searchRes.json();
    const items = searchData.items || [];
    let deletedAny = false;
    for (const item of items) {
      if (item.summary && item.summary.includes(bookingId)) {
        if (email) {
          const desc = (item.description || "").toLowerCase();
          const cleanEmail = String(email).trim().toLowerCase();
          if (!desc.includes(cleanEmail)) {
            console.warn(`Email mismatch for event ${bookingId}: ${cleanEmail} not found in event description.`);
            continue;
          }
        }
        const delRes = await fetch(
          `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(GOOGLE_CALENDAR_ID)}/events/${encodeURIComponent(item.id)}`,
          {
            method: "DELETE",
            headers: { "Authorization": `Bearer ${token}` }
          }
        );
        if (delRes.ok || delRes.status === 410) {
          deletedAny = true;
        } else {
          console.error(`Failed to delete Google Calendar event ${item.id}:`, await delRes.text());
        }
      }
    }
    return deletedAny;
  } catch (err) {
    console.error("Error deleting Google Calendar event:", err);
    return false;
  }
}
async function updateGoogleCalendarEventByBookingId(bookingId, email, newStartIso, newEndIso) {
  try {
    const token = await getAccessToken();
    if (!token || !GOOGLE_CALENDAR_ID) return false;
    const searchRes = await fetch(
      `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(GOOGLE_CALENDAR_ID)}/events?q=${encodeURIComponent(bookingId)}`,
      {
        headers: { "Authorization": `Bearer ${token}` }
      }
    );
    if (!searchRes.ok) {
      console.error("Google Calendar Event Search Error:", await searchRes.text());
      return false;
    }
    const searchData = await searchRes.json();
    const items = searchData.items || [];
    let updatedAny = false;
    for (const item of items) {
      if (item.summary && item.summary.includes(bookingId)) {
        if (email) {
          const desc = (item.description || "").toLowerCase();
          const cleanEmail = String(email).trim().toLowerCase();
          if (!desc.includes(cleanEmail)) {
            console.warn(`Email mismatch for event ${bookingId}: ${cleanEmail} not found in event description.`);
            continue;
          }
        }
        const currentDesc = item.description || "";
        const updatedDesc = `${currentDesc}

[RESCHEDULED ONLINE to ${newStartIso}]`;
        const patchRes = await fetch(
          `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(GOOGLE_CALENDAR_ID)}/events/${encodeURIComponent(item.id)}`,
          {
            method: "PATCH",
            headers: {
              "Authorization": `Bearer ${token}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              start: { dateTime: newStartIso, timeZone: "America/New_York" },
              end: { dateTime: newEndIso, timeZone: "America/New_York" },
              description: updatedDesc
            })
          }
        );
        if (patchRes.ok) {
          updatedAny = true;
        } else {
          console.error(`Failed to update Google Calendar event ${item.id}:`, await patchRes.text());
        }
      }
    }
    return updatedAny;
  } catch (err) {
    console.error("Error updating Google Calendar event:", err);
    return false;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createGoogleCalendarEvent,
  deleteGoogleCalendarEventByBookingId,
  getGoogleCalendarBusyRanges,
  updateGoogleCalendarEventByBookingId
});
