var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/ai-seo-reply.js
var ai_seo_reply_exports = {};
__export(ai_seo_reply_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(ai_seo_reply_exports);
async function handler(event, context) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  try {
    const body = JSON.parse(event.body || "{}");
    const { reviewerName, reviewText, town, service } = body;
    const name = reviewerName || "valued customer";
    const location = town || "Westchester County, NY";
    const jobService = service || "home maintenance";
    const westchesterCities = ["White Plains", "Scarsdale", "Yonkers", "Harrison", "Rye", "Mamaroneck", "Tarrytown", "Dobbs Ferry", "Eastchester"];
    const selectedCity = westchesterCities.find((c) => location.toLowerCase().includes(c.toLowerCase())) || "Westchester County";
    const templates = [
      `Thank you so much for the 5-star review, ${name}! We're thrilled we could help with your ${jobService} project in ${selectedCity}. At Here Handyman, we take pride in delivering prompt, professional, and reliable home repair services throughout Westchester County. We look forward to helping you again soon!`,
      `Hi ${name}, thank you for taking the time to share your experience with Here Handyman! It was a pleasure handling your ${jobService} in ${selectedCity}. Providing top-quality craftsmanship and clear communication is our top priority for every Westchester homeowner. Thanks again!`,
      `Thank you ${name}! We appreciate your business and kind words about our ${jobService} work in ${selectedCity}. Serving our local Westchester County community with reliable 5-star home maintenance is what we love to do. Give us a call anytime for your next project!`,
      `We're so happy to hear you're pleased with your ${jobService} in ${selectedCity}, ${name}! Thank you for choosing Here Handyman for your home repair needs in Westchester County. We're always here whenever you need expert local handyman service!`
    ];
    const idx = (name.length + (reviewText ? reviewText.length : 0)) % templates.length;
    const generatedReply = templates[idx];
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        reviewerName: name,
        location: selectedCity,
        service: jobService,
        seoReply: generatedReply
      })
    };
  } catch (err) {
    console.error("AI SEO Reply Generation Error:", err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ success: false, error: err.message })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
