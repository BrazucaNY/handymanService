var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/availability.js
var availability_exports = {};
__export(availability_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(availability_exports);

// netlify/functions/dbConfig.js
var DB_CONFIG = {
  SUPABASE_URL: process.env.SUPABASE_URL || "https://vvwnmiffuaxiazlskeya.supabase.co",
  SUPABASE_SERVICE_ROLE_KEY: process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY || "sb_publishable_-kxhroGZF03Y-RkyJ_bVTQ_5MQZRCZc"
};

// netlify/functions/googleCalendar.js
var import_node_crypto = __toESM(require("crypto"), 1);
var saProject = process.env.FIREBASE_PROJECT_ID || "handymanserviceadmin";
var GOOGLE_SA_EMAIL = process.env.GOOGLE_SA_EMAIL || `herehandyman-booking@${saProject}.iam.gserviceaccount.com`;
var GOOGLE_SA_PRIVATE_KEY = (process.env.GOOGLE_SA_PRIVATE_KEY || "").replace(/\\n/g, "\n");
var GOOGLE_CALENDAR_ID = process.env.GOOGLE_CALENDAR_ID || "davi65@gmail.com";
async function getAccessToken() {
  if (!GOOGLE_SA_EMAIL || !GOOGLE_SA_PRIVATE_KEY) {
    return null;
  }
  const now = Math.floor(Date.now() / 1e3);
  const header = { alg: "RS256", typ: "JWT" };
  const claimSet = {
    iss: GOOGLE_SA_EMAIL,
    scope: "https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/calendar.events",
    aud: "https://oauth2.googleapis.com/token",
    exp: now + 3600,
    iat: now
  };
  const b64Header = Buffer.from(JSON.stringify(header)).toString("base64url");
  const b64ClaimSet = Buffer.from(JSON.stringify(claimSet)).toString("base64url");
  const unsignedJwt = `${b64Header}.${b64ClaimSet}`;
  const signer = import_node_crypto.default.createSign("RSA-SHA256");
  signer.update(unsignedJwt);
  const signature = signer.sign(GOOGLE_SA_PRIVATE_KEY, "base64url");
  const jwt = `${unsignedJwt}.${signature}`;
  const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: jwt
    })
  });
  if (!tokenRes.ok) {
    const errorText = await tokenRes.text();
    console.error("Google OAuth token error:", errorText);
    return null;
  }
  const tokenData = await tokenRes.json();
  return tokenData.access_token;
}
async function getGoogleCalendarBusyRanges(dayStartIso, dayEndIso) {
  try {
    const token = await getAccessToken();
    if (!token || !GOOGLE_CALENDAR_ID) return [];
    const res = await fetch("https://www.googleapis.com/calendar/v3/freeBusy", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        timeMin: dayStartIso,
        timeMax: dayEndIso,
        timeZone: "America/New_York",
        items: [{ id: GOOGLE_CALENDAR_ID }]
      })
    });
    if (!res.ok) {
      console.error("Google FreeBusy error:", await res.text());
      return [];
    }
    const data = await res.json();
    const calendarData = data.calendars && data.calendars[GOOGLE_CALENDAR_ID];
    const busyList = calendarData ? calendarData.busy || [] : [];
    return busyList.map((item) => ({
      start: new Date(item.start).getTime(),
      end: new Date(item.end).getTime()
    }));
  } catch (err) {
    console.error("Error fetching Google Calendar busy ranges:", err);
    return [];
  }
}

// netlify/functions/availability.js
async function handler(event) {
  if (event.httpMethod !== "GET") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method Not Allowed" }) };
  }
  const { date, serviceId } = event.queryStringParameters || {};
  if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    return {
      statusCode: 400,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Missing or invalid 'date' parameter (expected YYYY-MM-DD)" })
    };
  }
  const SUPABASE_URL = DB_CONFIG.SUPABASE_URL;
  const SUPABASE_SERVICE_ROLE_KEY = DB_CONFIG.SUPABASE_SERVICE_ROLE_KEY;
  let bookedRanges = [];
  const [yr, mo, dy] = date.split("-").map(Number);
  const dayStart = new Date(Date.UTC(yr, mo - 1, dy, 4, 0, 0)).toISOString();
  const dayEnd = new Date(Date.UTC(yr, mo - 1, dy + 1, 3, 59, 59)).toISOString();
  try {
    const googleBusy = await getGoogleCalendarBusyRanges(dayStart, dayEnd);
    if (googleBusy && googleBusy.length > 0) {
      bookedRanges.push(...googleBusy);
    }
  } catch (gErr) {
    console.error("Google Calendar API check warning:", gErr);
  }
  if (SUPABASE_URL && SUPABASE_SERVICE_ROLE_KEY && !SUPABASE_URL.includes("YOUR_SUPABASE")) {
    try {
      const url = `${SUPABASE_URL}/rest/v1/bookings?start_time=gte.${encodeURIComponent(dayStart)}&start_time=lte.${encodeURIComponent(dayEnd)}&status=eq.confirmed&customer_name=neq.David&select=start_time,end_time,customer_name`;
      const response = await fetch(url, {
        headers: {
          "apikey": SUPABASE_SERVICE_ROLE_KEY,
          "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`
        }
      });
      if (response.ok) {
        const rows = await response.json();
        const supabaseRanges = (rows || []).filter((r) => {
          const name = (r.customer_name || "").toLowerCase();
          return !name.includes("david") && !name.includes("test");
        }).map((r) => ({
          start: new Date(r.start_time).getTime(),
          end: new Date(r.end_time).getTime()
        }));
        bookedRanges.push(...supabaseRanges);
      }
    } catch (err) {
      console.error("Database query error:", err);
    }
  }
  const durationMinutes = serviceId === "drywall" || serviceId === "painting" ? 120 : serviceId === "general" ? 180 : 60;
  const slots = [];
  const bufferMs = 30 * 60 * 1e3;
  const durationMs = durationMinutes * 60 * 1e3;
  const stepMs = 60 * 60 * 1e3;
  const workStartMs = Date.UTC(yr, mo - 1, dy, 11, 0, 0);
  const lastStartMs = Date.UTC(yr, mo - 1, dy, 23, 0, 0);
  const nowMs = Date.now();
  for (let currentStart = workStartMs; currentStart <= lastStartMs; currentStart += stepMs) {
    const candidateTotalEnd = currentStart + durationMs + bufferMs;
    if (currentStart <= nowMs + 1 * 3600 * 1e3) continue;
    const isBlocked = bookedRanges.some((b) => currentStart < b.end && b.start < candidateTotalEnd);
    if (!isBlocked) {
      const dateObj = new Date(currentStart);
      const timeLabel = new Intl.DateTimeFormat("en-US", {
        timeZone: "America/New_York",
        hour: "numeric",
        minute: "2-digit",
        hour12: true
      }).format(dateObj);
      slots.push({
        iso: dateObj.toISOString(),
        timestamp: currentStart,
        label: timeLabel
      });
    }
  }
  return {
    statusCode: 200,
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": "no-cache, no-store, must-revalidate"
    },
    body: JSON.stringify({ date, serviceId, slots })
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
