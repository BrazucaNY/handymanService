var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/cancel.js
var cancel_exports = {};
__export(cancel_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(cancel_exports);

// netlify/functions/dbConfig.js
var DB_CONFIG = {
  SUPABASE_URL: process.env.SUPABASE_URL || "https://vvwnmiffuaxiazlskeya.supabase.co",
  SUPABASE_SERVICE_ROLE_KEY: process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY || "sb_publishable_-kxhroGZF03Y-RkyJ_bVTQ_5MQZRCZc"
};

// netlify/functions/googleCalendar.js
var import_node_crypto = __toESM(require("crypto"), 1);
var saProject = process.env.FIREBASE_PROJECT_ID || "handymanserviceadmin";
var GOOGLE_SA_EMAIL = process.env.GOOGLE_SA_EMAIL || `herehandyman-booking@${saProject}.iam.gserviceaccount.com`;
var GOOGLE_SA_PRIVATE_KEY = (process.env.GOOGLE_SA_PRIVATE_KEY || "").replace(/\\n/g, "\n");
var GOOGLE_CALENDAR_ID = process.env.GOOGLE_CALENDAR_ID || "davi65@gmail.com";
async function getAccessToken() {
  if (!GOOGLE_SA_EMAIL || !GOOGLE_SA_PRIVATE_KEY) {
    return null;
  }
  const now = Math.floor(Date.now() / 1e3);
  const header = { alg: "RS256", typ: "JWT" };
  const claimSet = {
    iss: GOOGLE_SA_EMAIL,
    scope: "https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/calendar.events",
    aud: "https://oauth2.googleapis.com/token",
    exp: now + 3600,
    iat: now
  };
  const b64Header = Buffer.from(JSON.stringify(header)).toString("base64url");
  const b64ClaimSet = Buffer.from(JSON.stringify(claimSet)).toString("base64url");
  const unsignedJwt = `${b64Header}.${b64ClaimSet}`;
  const signer = import_node_crypto.default.createSign("RSA-SHA256");
  signer.update(unsignedJwt);
  const signature = signer.sign(GOOGLE_SA_PRIVATE_KEY, "base64url");
  const jwt = `${unsignedJwt}.${signature}`;
  const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: jwt
    })
  });
  if (!tokenRes.ok) {
    const errorText = await tokenRes.text();
    console.error("Google OAuth token error:", errorText);
    return null;
  }
  const tokenData = await tokenRes.json();
  return tokenData.access_token;
}
async function deleteGoogleCalendarEventByBookingId(bookingId, email) {
  try {
    const token = await getAccessToken();
    if (!token || !GOOGLE_CALENDAR_ID) return false;
    const searchRes = await fetch(
      `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(GOOGLE_CALENDAR_ID)}/events?q=${encodeURIComponent(bookingId)}`,
      {
        headers: { "Authorization": `Bearer ${token}` }
      }
    );
    if (!searchRes.ok) {
      console.error("Google Calendar Event Search Error:", await searchRes.text());
      return false;
    }
    const searchData = await searchRes.json();
    const items = searchData.items || [];
    let deletedAny = false;
    for (const item of items) {
      if (item.summary && item.summary.includes(bookingId)) {
        if (email) {
          const desc = (item.description || "").toLowerCase();
          const cleanEmail = String(email).trim().toLowerCase();
          if (!desc.includes(cleanEmail)) {
            console.warn(`Email mismatch for event ${bookingId}: ${cleanEmail} not found in event description.`);
            continue;
          }
        }
        const delRes = await fetch(
          `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(GOOGLE_CALENDAR_ID)}/events/${encodeURIComponent(item.id)}`,
          {
            method: "DELETE",
            headers: { "Authorization": `Bearer ${token}` }
          }
        );
        if (delRes.ok || delRes.status === 410) {
          deletedAny = true;
        } else {
          console.error(`Failed to delete Google Calendar event ${item.id}:`, await delRes.text());
        }
      }
    }
    return deletedAny;
  } catch (err) {
    console.error("Error deleting Google Calendar event:", err);
    return false;
  }
}

// netlify/functions/cancel.js
async function handler(event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method Not Allowed" }) };
  }
  try {
    let body;
    try {
      body = JSON.parse(event.body);
    } catch (parseErr) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Invalid JSON request body." })
      };
    }
    const { bookingId, email } = body;
    if (!bookingId || !email) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Booking ID and Email Address are required to cancel an appointment." })
      };
    }
    const cleanBookingId = String(bookingId).trim().toUpperCase();
    const cleanEmail = String(email).trim().toLowerCase();
    const SUPABASE_URL = DB_CONFIG.SUPABASE_URL;
    const SUPABASE_SERVICE_ROLE_KEY = DB_CONFIG.SUPABASE_SERVICE_ROLE_KEY;
    let dbBooking = null;
    if (SUPABASE_URL && SUPABASE_SERVICE_ROLE_KEY && !SUPABASE_URL.includes("YOUR_SUPABASE")) {
      const getRes = await fetch(`${SUPABASE_URL}/rest/v1/bookings?id=eq.${encodeURIComponent(cleanBookingId)}`, {
        headers: {
          "apikey": SUPABASE_SERVICE_ROLE_KEY,
          "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`
        }
      });
      if (getRes.ok) {
        const rows = await getRes.json();
        if (rows && rows.length > 0) {
          dbBooking = rows[0];
        }
      }
    }
    if (dbBooking) {
      if (dbBooking.status === "cancelled") {
        return {
          statusCode: 400,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ error: "This appointment has already been cancelled." })
        };
      }
      const storedEmail = (dbBooking.customer_email || "").trim().toLowerCase();
      if (storedEmail && storedEmail !== cleanEmail) {
        return {
          statusCode: 400,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ error: "The email address provided does not match our records for this booking." })
        };
      }
      await fetch(`${SUPABASE_URL}/rest/v1/bookings?id=eq.${encodeURIComponent(cleanBookingId)}`, {
        method: "PATCH",
        headers: {
          "apikey": SUPABASE_SERVICE_ROLE_KEY,
          "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
          "Content-Type": "application/json",
          "Prefer": "return=minimal"
        },
        body: JSON.stringify({ status: "cancelled" })
      }).catch((err) => console.error("Supabase update error:", err));
    }
    const calendarDeleted = await deleteGoogleCalendarEventByBookingId(cleanBookingId, cleanEmail);
    if (!dbBooking && !calendarDeleted) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Booking ID not found. Please verify your booking ID." })
      };
    }
    const custName = dbBooking ? dbBooking.customer_name : "Customer";
    const custPhone = dbBooking ? dbBooking.customer_phone : "N/A";
    const startTime = dbBooking ? dbBooking.start_time : "N/A";
    fetch("https://api.web3forms.com/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        access_key: "5cd5e45a-9146-4c3a-ac2f-8b2904476cf0",
        subject: `\u274C APPOINTMENT CANCELLED #${cleanBookingId}`,
        from_name: "Here Handyman Online Cancellation",
        message: `AN APPOINTMENT HAS BEEN CANCELLED ONLINE

Booking ID: ${cleanBookingId}
Customer Name: ${custName}
Phone: ${custPhone}
Email: ${cleanEmail}
Scheduled Start Time: ${startTime}
Google Calendar Removed: ${calendarDeleted ? "YES" : "NO/NOT FOUND"}`
      })
    }).catch((err) => console.error("Web3Forms cancellation email background error:", err));
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        success: true,
        bookingId: cleanBookingId,
        message: `Appointment ${cleanBookingId} has been successfully cancelled.`
      })
    };
  } catch (err) {
    console.error("Cancellation handler error:", err);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Internal server error during cancellation." })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
