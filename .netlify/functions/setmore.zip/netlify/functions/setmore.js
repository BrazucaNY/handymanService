var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/setmore.js
var setmore_exports = {};
__export(setmore_exports, {
  createOrGetSetmoreCustomer: () => createOrGetSetmoreCustomer,
  createSetmoreAppointment: () => createSetmoreAppointment,
  getSetmoreAccessToken: () => getSetmoreAccessToken,
  getSetmoreSlots: () => getSetmoreSlots
});
module.exports = __toCommonJS(setmore_exports);
var import_node_https = __toESM(require("https"), 1);
var SETMORE_REFRESH_TOKEN = process.env.SETMORE_REFRESH_TOKEN || "r1/b9ac1e2a5bq66TP8pWitf0crZXjF9TkqIMqrpFr28gixe";
var DAVID_STAFF_KEY = "6df5336e-23d0-4bfc-94a7-12dfbb70416e";
var SETMORE_SERVICES = {
  drywall: "0d83598c-3ba8-4575-8c59-5e9731ad266b",
  painting: "0d83598c-3ba8-4575-8c59-5e9731ad266b",
  tv: "48dbf914-6bad-426a-baf6-0d8d2a5fb235",
  furniture: "48dbf914-6bad-426a-baf6-0d8d2a5fb235",
  assembly: "48dbf914-6bad-426a-baf6-0d8d2a5fb235",
  carpentry: "8d634355-c9e6-4f71-9255-d1a774fdff14",
  electrical: "8d634355-c9e6-4f71-9255-d1a774fdff14",
  fixtures: "8d634355-c9e6-4f71-9255-d1a774fdff14",
  plumbing: "8d634355-c9e6-4f71-9255-d1a774fdff14",
  general: "8d634355-c9e6-4f71-9255-d1a774fdff14"
};
var cachedToken = null;
var tokenExpiresAt = 0;
async function getSetmoreAccessToken() {
  const now = Date.now();
  if (cachedToken && tokenExpiresAt > now + 6e4) {
    return cachedToken;
  }
  return new Promise((resolve, reject) => {
    const url = `https://developer.setmore.com/api/v1/o/oauth2/token?refreshToken=${encodeURIComponent(SETMORE_REFRESH_TOKEN)}`;
    import_node_https.default.get(url, (res) => {
      let data = "";
      res.on("data", (chunk) => data += chunk);
      res.on("end", () => {
        try {
          const parsed = JSON.parse(data);
          if (parsed.response && parsed.data && parsed.data.token) {
            cachedToken = parsed.data.token.access_token;
            tokenExpiresAt = Date.now() + (parsed.data.token.expires_in || 7200) * 1e3;
            resolve(cachedToken);
          } else {
            reject(new Error(`Failed to refresh Setmore token: ${data}`));
          }
        } catch (e) {
          reject(e);
        }
      });
    }).on("error", reject);
  });
}
async function callSetmoreApi(path, method = "GET", postData = null) {
  const token = await getSetmoreAccessToken();
  return new Promise((resolve, reject) => {
    const options = {
      hostname: "developer.setmore.com",
      path,
      method,
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json"
      }
    };
    const req = import_node_https.default.request(options, (res) => {
      let body = "";
      res.on("data", (chunk) => body += chunk);
      res.on("end", () => {
        try {
          resolve(JSON.parse(body));
        } catch (e) {
          resolve({ raw: body, statusCode: res.statusCode });
        }
      });
    });
    req.on("error", reject);
    if (postData) {
      req.write(JSON.stringify(postData));
    }
    req.end();
  });
}
async function createOrGetSetmoreCustomer({ name, email, phone }) {
  try {
    const nameParts = (name || "Valued Customer").trim().split(" ");
    const firstName = nameParts[0] || "Valued";
    const lastName = nameParts.slice(1).join(" ") || "Customer";
    const res = await callSetmoreApi("/api/v1/bookingapi/customer/create", "POST", {
      first_name: firstName,
      last_name: lastName,
      email_id: email || "customer@herehandyman.com",
      cell_phone: (phone || "").replace(/\D/g, "")
    });
    if (res.response && res.data && res.data.customer && res.data.customer.key) {
      return res.data.customer.key;
    }
    return null;
  } catch (err) {
    console.error("Error creating Setmore customer:", err);
    return null;
  }
}
async function createSetmoreAppointment({ name, email, phone, startISO, endISO, serviceId, notes, address, zip }) {
  try {
    const customerKey = await createOrGetSetmoreCustomer({ name, email, phone });
    const serviceKey = SETMORE_SERVICES[serviceId] || SETMORE_SERVICES.general;
    const comment = `HereHandyman.com Booking | Address: ${address || "N/A"}, ZIP: ${zip || "N/A"} | Phone: ${phone || "N/A"} | Notes: ${notes || "None"}`;
    const apptData = {
      staff_key: DAVID_STAFF_KEY,
      service_key: serviceKey,
      customer_key: customerKey,
      start_time: startISO,
      end_time: endISO,
      comment
    };
    const result = await callSetmoreApi("/api/v1/bookingapi/appointment/create", "POST", apptData);
    console.log("Setmore appointment creation result:", JSON.stringify(result));
    return result;
  } catch (err) {
    console.error("Failed to create Setmore appointment:", err);
    return null;
  }
}
async function getSetmoreSlots(dateStrDDMMYYYY, serviceId = "general") {
  try {
    const serviceKey = SETMORE_SERVICES[serviceId] || SETMORE_SERVICES.general;
    const res = await callSetmoreApi("/api/v1/bookingapi/slots", "POST", {
      staff_key: DAVID_STAFF_KEY,
      service_key: serviceKey,
      selected_date: dateStrDDMMYYYY,
      off_hours: false
    });
    if (res.response && res.data && Array.isArray(res.data.slots)) {
      return res.data.slots;
    }
    return [];
  } catch (err) {
    console.error("Error fetching Setmore slots:", err);
    return [];
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createOrGetSetmoreCustomer,
  createSetmoreAppointment,
  getSetmoreAccessToken,
  getSetmoreSlots
});
