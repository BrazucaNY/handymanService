var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/auto-review-responder.js
var auto_review_responder_exports = {};
__export(auto_review_responder_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(auto_review_responder_exports);
var import_node_crypto = __toESM(require("crypto"));
var saProject = process.env.FIREBASE_PROJECT_ID || "handymanserviceadmin";
var client_email = process.env.GOOGLE_SA_EMAIL || `herehandyman-booking@${saProject}.iam.gserviceaccount.com`;
var private_key = (process.env.GOOGLE_SA_PRIVATE_KEY || "").replace(/\\n/g, "\n");
var client_id = process.env.GOOGLE_CLIENT_ID;
var client_secret = process.env.GOOGLE_CLIENT_SECRET;
var refresh_token = process.env.GOOGLE_OAUTH_REFRESH_TOKEN || process.env.GOOGLE_REFRESH_TOKEN;
async function getAccessToken() {
  if (client_id && client_secret && refresh_token) {
    const tokenRes2 = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id,
        client_secret,
        refresh_token,
        grant_type: "refresh_token"
      })
    });
    if (tokenRes2.ok) {
      const tokenData2 = await tokenRes2.json();
      return { token: tokenData2.access_token, authType: "User OAuth (davi65@gmail.com)" };
    }
  }
  const now = Math.floor(Date.now() / 1e3);
  const header = { alg: "RS256", typ: "JWT" };
  const claimSet = {
    iss: client_email,
    scope: "https://www.googleapis.com/auth/business.manage",
    aud: "https://oauth2.googleapis.com/token",
    exp: now + 3600,
    iat: now
  };
  const b64Header = Buffer.from(JSON.stringify(header)).toString("base64url");
  const b64ClaimSet = Buffer.from(JSON.stringify(claimSet)).toString("base64url");
  const unsignedJwt = `${b64Header}.${b64ClaimSet}`;
  const signer = import_node_crypto.default.createSign("RSA-SHA256");
  signer.update(unsignedJwt);
  const signature = signer.sign(private_key, "base64url");
  const jwt = `${unsignedJwt}.${signature}`;
  const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: jwt
    })
  });
  if (!tokenRes.ok) {
    const errText = await tokenRes.text();
    throw new Error("Google OAuth token error: " + errText);
  }
  const tokenData = await tokenRes.json();
  return { token: tokenData.access_token, authType: `Service Account (${client_email})` };
}
function generateSeoReply(reviewerName, commentText, starRating) {
  const name = reviewerName || "valued customer";
  const westchesterCities = ["White Plains", "Scarsdale", "Yonkers", "Harrison", "Rye", "Mamaroneck", "Tarrytown", "Ardsley", "Dobbs Ferry", "Eastchester"];
  const idx = name.length % westchesterCities.length;
  const town = westchesterCities[idx];
  if (starRating === "FIVE" || starRating === 5 || !starRating) {
    if (commentText && commentText.length > 5) {
      return `${name}, thank you so much for the 5-star review! It was a real pleasure helping out with your project in ${town}. At Here Handyman, we take pride in delivering prompt, clean, top-quality home repairs across Westchester County. Looking forward to helping you again anytime! David, Here Handyman`;
    }
    return `${name}, thank you for choosing Here Handyman! Providing reliable 5-star home maintenance and repairs in ${town} and Westchester County is what we love to do. Give us a call anytime for your next project! David, Here Handyman`;
  }
  if (starRating === "FOUR" || starRating === 4) {
    return `Thank you for the feedback and 4-star rating, ${name}! We're glad we could assist with your home repair in ${town}. We always strive for 100% satisfaction \u2014 feel free to call or text us anytime at (516) 350-0801 for your next project! David, Here Handyman`;
  }
  return `I'm truly sorry to hear your experience didn't meet the high standards we hold ourselves to, ${name}. I'd love the opportunity to make this right. Please reach out to me directly at (516) 350-0801 so we can talk through what happened. David, Here Handyman`;
}
async function handler(event, context) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  try {
    const { token: accessToken, authType } = await getAccessToken();
    const accountsRes = await fetch("https://mybusinessaccountmanagement.googleapis.com/v1/accounts", {
      headers: { "Authorization": `Bearer ${accessToken}` }
    });
    const accountsData = await accountsRes.json();
    if (!accountsData.accounts || accountsData.accounts.length === 0) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          authType,
          processed: 0,
          message: "No Google Business Profile accounts found or quota pending."
        })
      };
    }
    let totalReplied = 0;
    const results = [];
    for (const account of accountsData.accounts) {
      const locRes = await fetch(`https://mybusinessinformation.googleapis.com/v1/${account.name}/locations`, {
        headers: { "Authorization": `Bearer ${accessToken}` }
      });
      const locData = await locRes.json();
      const locations = locData.locations || [];
      for (const loc of locations) {
        const reviewsRes = await fetch(`https://mybusiness.googleapis.com/v4/${loc.name}/reviews`, {
          headers: { "Authorization": `Bearer ${accessToken}` }
        });
        if (!reviewsRes.ok) continue;
        const reviewsData = await reviewsRes.json();
        const reviews = reviewsData.reviews || [];
        for (const rev of reviews) {
          if (!rev.reviewReply) {
            const reviewerName = rev.reviewer ? rev.reviewer.displayName : "valued customer";
            const commentText = rev.comment || "";
            const starRating = rev.starRating || 5;
            const seoReplyText = generateSeoReply(reviewerName, commentText, starRating);
            const replyRes = await fetch(`https://mybusiness.googleapis.com/v4/${rev.name}/reply`, {
              method: "PUT",
              headers: {
                "Authorization": `Bearer ${accessToken}`,
                "Content-Type": "application/json"
              },
              body: JSON.stringify({ comment: seoReplyText })
            });
            if (replyRes.ok) {
              totalReplied++;
              results.push({
                reviewId: rev.reviewId,
                reviewerName,
                starRating,
                postedReply: seoReplyText
              });
            }
          }
        }
      }
    }
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        authType,
        totalReplied,
        replies: results,
        message: `Auto-review monitor cycle completed. Published ${totalReplied} replies.`
      })
    };
  } catch (err) {
    console.error("Auto Review Responder Error:", err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ success: false, error: err.message })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
