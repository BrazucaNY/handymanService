var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/gbp-reviews.js
var gbp_reviews_exports = {};
__export(gbp_reviews_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(gbp_reviews_exports);
var import_node_crypto = __toESM(require("crypto"), 1);
var saProject = process.env.FIREBASE_PROJECT_ID || "handymanserviceadmin";
var client_email = process.env.GOOGLE_SA_EMAIL || `herehandyman-booking@${saProject}.iam.gserviceaccount.com`;
var private_key = (process.env.GOOGLE_SA_PRIVATE_KEY || "").replace(/\\n/g, "\n");
async function getAccessToken() {
  const now = Math.floor(Date.now() / 1e3);
  const header = { alg: "RS256", typ: "JWT" };
  const claimSet = {
    iss: client_email,
    scope: "https://www.googleapis.com/auth/business.manage",
    aud: "https://oauth2.googleapis.com/token",
    exp: now + 3600,
    iat: now
  };
  const b64Header = Buffer.from(JSON.stringify(header)).toString("base64url");
  const b64ClaimSet = Buffer.from(JSON.stringify(claimSet)).toString("base64url");
  const unsignedJwt = `${b64Header}.${b64ClaimSet}`;
  const signer = import_node_crypto.default.createSign("RSA-SHA256");
  signer.update(unsignedJwt);
  const signature = signer.sign(private_key, "base64url");
  const jwt = `${unsignedJwt}.${signature}`;
  const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: jwt
    })
  });
  if (!tokenRes.ok) {
    const errText = await tokenRes.text();
    throw new Error("Google OAuth token error: " + errText);
  }
  const tokenData = await tokenRes.json();
  return tokenData.access_token;
}
async function handler(event, context) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  try {
    const accessToken = await getAccessToken();
    if (event.httpMethod === "GET") {
      const accountsRes = await fetch("https://mybusinessaccountmanagement.googleapis.com/v1/accounts", {
        headers: { "Authorization": `Bearer ${accessToken}` }
      });
      let accountsData = {};
      if (accountsRes.ok) {
        accountsData = await accountsRes.json();
      }
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          authenticated: true,
          clientEmail: client_email,
          accounts: accountsData.accounts || [],
          message: "Successfully authenticated with Google Business Profile API!"
        })
      };
    }
    if (event.httpMethod === "POST") {
      const body = JSON.parse(event.body || "{}");
      const { reviewName, replyComment } = body;
      if (!reviewName || !replyComment) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: "reviewName and replyComment are required" })
        };
      }
      const replyRes = await fetch(`https://mybusiness.googleapis.com/v4/${reviewName}/reply`, {
        method: "PUT",
        headers: {
          "Authorization": `Bearer ${accessToken}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ comment: replyComment })
      });
      const replyData = await replyRes.json();
      return {
        statusCode: replyRes.status,
        headers,
        body: JSON.stringify({
          success: replyRes.ok,
          reply: replyData,
          message: replyRes.ok ? "Successfully posted reply to Google!" : "Failed to post reply to Google."
        })
      };
    }
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method Not Allowed" }) };
  } catch (err) {
    console.error("GBP API Handler Error:", err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ success: false, error: err.message })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
