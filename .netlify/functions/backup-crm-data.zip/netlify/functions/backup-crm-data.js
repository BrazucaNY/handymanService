var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/backup-crm-data.js
var backup_crm_data_exports = {};
__export(backup_crm_data_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(backup_crm_data_exports);
async function handler(event, context) {
  const authHeader = event.headers.authorization || event.headers.Authorization || "";
  const cronSecret = process.env.CRON_BACKUP_SECRET || "hh_crm_secret_backup_key";
  if (!authHeader.includes(cronSecret) && !authHeader.includes("Bearer")) {
    return {
      statusCode: 401,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Unauthorized backup request." })
    };
  }
  const supabaseUrl = process.env.SUPABASE_URL || "https://vvwnmiffuaxiazlskeya.supabase.co";
  const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_KEY || "";
  try {
    const headers = {
      "apikey": supabaseKey,
      "Authorization": `Bearer ${supabaseKey}`,
      "Content-Type": "application/json"
    };
    const reviewsRes = await fetch(`${supabaseUrl}/rest/v1/customer_reviews?select=*`, { headers });
    const reviewsData = reviewsRes.ok ? await reviewsRes.json() : [];
    const backupSnapshot = {
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      recordCounts: {
        reviews: Array.isArray(reviewsData) ? reviewsData.length : 0
      },
      data: reviewsData
    };
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "no-store, no-cache"
      },
      body: JSON.stringify({
        success: true,
        message: "CRM Database Backup snapshot created successfully.",
        snapshot: backupSnapshot
      })
    };
  } catch (err) {
    console.error("CRM Data Backup Error:", err);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Failed to create database backup snapshot.", details: err.message })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
