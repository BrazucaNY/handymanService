var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/reschedule.js
var reschedule_exports = {};
__export(reschedule_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(reschedule_exports);

// netlify/functions/dbConfig.js
var DB_CONFIG = {
  SUPABASE_URL: process.env.SUPABASE_URL || "https://vvwnmiffuaxiazlskeya.supabase.co",
  SUPABASE_SERVICE_ROLE_KEY: process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY || "sb_publishable_-kxhroGZF03Y-RkyJ_bVTQ_5MQZRCZc"
};

// netlify/functions/googleCalendar.js
var import_node_crypto = __toESM(require("crypto"), 1);
var saProject = process.env.FIREBASE_PROJECT_ID || "handymanserviceadmin";
var GOOGLE_SA_EMAIL = process.env.GOOGLE_SA_EMAIL || `herehandyman-booking@${saProject}.iam.gserviceaccount.com`;
var GOOGLE_SA_PRIVATE_KEY = (process.env.GOOGLE_SA_PRIVATE_KEY || "").replace(/\\n/g, "\n");
var GOOGLE_CALENDAR_ID = process.env.GOOGLE_CALENDAR_ID || "davi65@gmail.com";
async function getAccessToken() {
  if (!GOOGLE_SA_EMAIL || !GOOGLE_SA_PRIVATE_KEY) {
    return null;
  }
  const now = Math.floor(Date.now() / 1e3);
  const header = { alg: "RS256", typ: "JWT" };
  const claimSet = {
    iss: GOOGLE_SA_EMAIL,
    scope: "https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/calendar.events",
    aud: "https://oauth2.googleapis.com/token",
    exp: now + 3600,
    iat: now
  };
  const b64Header = Buffer.from(JSON.stringify(header)).toString("base64url");
  const b64ClaimSet = Buffer.from(JSON.stringify(claimSet)).toString("base64url");
  const unsignedJwt = `${b64Header}.${b64ClaimSet}`;
  const signer = import_node_crypto.default.createSign("RSA-SHA256");
  signer.update(unsignedJwt);
  const signature = signer.sign(GOOGLE_SA_PRIVATE_KEY, "base64url");
  const jwt = `${unsignedJwt}.${signature}`;
  const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: jwt
    })
  });
  if (!tokenRes.ok) {
    const errorText = await tokenRes.text();
    console.error("Google OAuth token error:", errorText);
    return null;
  }
  const tokenData = await tokenRes.json();
  return tokenData.access_token;
}
async function getGoogleCalendarBusyRanges(dayStartIso, dayEndIso) {
  try {
    const token = await getAccessToken();
    if (!token || !GOOGLE_CALENDAR_ID) return [];
    const res = await fetch("https://www.googleapis.com/calendar/v3/freeBusy", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        timeMin: dayStartIso,
        timeMax: dayEndIso,
        timeZone: "America/New_York",
        items: [{ id: GOOGLE_CALENDAR_ID }]
      })
    });
    if (!res.ok) {
      console.error("Google FreeBusy error:", await res.text());
      return [];
    }
    const data = await res.json();
    const calendarData = data.calendars && data.calendars[GOOGLE_CALENDAR_ID];
    const busyList = calendarData ? calendarData.busy || [] : [];
    return busyList.map((item) => ({
      start: new Date(item.start).getTime(),
      end: new Date(item.end).getTime()
    }));
  } catch (err) {
    console.error("Error fetching Google Calendar busy ranges:", err);
    return [];
  }
}
async function updateGoogleCalendarEventByBookingId(bookingId, email, newStartIso, newEndIso) {
  try {
    const token = await getAccessToken();
    if (!token || !GOOGLE_CALENDAR_ID) return false;
    const searchRes = await fetch(
      `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(GOOGLE_CALENDAR_ID)}/events?q=${encodeURIComponent(bookingId)}`,
      {
        headers: { "Authorization": `Bearer ${token}` }
      }
    );
    if (!searchRes.ok) {
      console.error("Google Calendar Event Search Error:", await searchRes.text());
      return false;
    }
    const searchData = await searchRes.json();
    const items = searchData.items || [];
    let updatedAny = false;
    for (const item of items) {
      if (item.summary && item.summary.includes(bookingId)) {
        if (email) {
          const desc = (item.description || "").toLowerCase();
          const cleanEmail = String(email).trim().toLowerCase();
          if (!desc.includes(cleanEmail)) {
            console.warn(`Email mismatch for event ${bookingId}: ${cleanEmail} not found in event description.`);
            continue;
          }
        }
        const currentDesc = item.description || "";
        const updatedDesc = `${currentDesc}

[RESCHEDULED ONLINE to ${newStartIso}]`;
        const patchRes = await fetch(
          `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(GOOGLE_CALENDAR_ID)}/events/${encodeURIComponent(item.id)}`,
          {
            method: "PATCH",
            headers: {
              "Authorization": `Bearer ${token}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              start: { dateTime: newStartIso, timeZone: "America/New_York" },
              end: { dateTime: newEndIso, timeZone: "America/New_York" },
              description: updatedDesc
            })
          }
        );
        if (patchRes.ok) {
          updatedAny = true;
        } else {
          console.error(`Failed to update Google Calendar event ${item.id}:`, await patchRes.text());
        }
      }
    }
    return updatedAny;
  } catch (err) {
    console.error("Error updating Google Calendar event:", err);
    return false;
  }
}

// netlify/functions/reschedule.js
var SERVICE_DURATIONS = {
  tv: 60,
  furniture: 60,
  assembly: 60,
  drywall: 120,
  painting: 120,
  electrical: 60,
  fixtures: 60,
  plumbing: 60,
  general: 180
};
async function handler(event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method Not Allowed" }) };
  }
  try {
    let body;
    try {
      body = JSON.parse(event.body);
    } catch (parseErr) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Invalid JSON request body." })
      };
    }
    const { bookingId, email, newStart } = body;
    if (!bookingId || !email || !newStart) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Booking ID, Email Address, and New Date/Time are required." })
      };
    }
    const cleanBookingId = String(bookingId).trim().toUpperCase();
    const cleanEmail = String(email).trim().toLowerCase();
    const startMs = new Date(newStart).getTime();
    if (isNaN(startMs)) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Invalid new appointment date format." })
      };
    }
    if (startMs <= Date.now()) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "New appointment date must be in the future." })
      };
    }
    const SUPABASE_URL = DB_CONFIG.SUPABASE_URL;
    const SUPABASE_SERVICE_ROLE_KEY = DB_CONFIG.SUPABASE_SERVICE_ROLE_KEY;
    let dbBooking = null;
    if (SUPABASE_URL && SUPABASE_SERVICE_ROLE_KEY && !SUPABASE_URL.includes("YOUR_SUPABASE")) {
      const getRes = await fetch(`${SUPABASE_URL}/rest/v1/bookings?id=eq.${encodeURIComponent(cleanBookingId)}`, {
        headers: {
          "apikey": SUPABASE_SERVICE_ROLE_KEY,
          "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`
        }
      });
      if (getRes.ok) {
        const rows = await getRes.json();
        if (rows && rows.length > 0) {
          dbBooking = rows[0];
        }
      }
    }
    if (dbBooking) {
      if (dbBooking.status === "cancelled") {
        return {
          statusCode: 400,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ error: "This appointment was cancelled. Please submit a new booking instead." })
        };
      }
      const storedEmail = (dbBooking.customer_email || "").trim().toLowerCase();
      if (storedEmail && storedEmail !== cleanEmail) {
        return {
          statusCode: 400,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ error: "The email address provided does not match our records for this booking." })
        };
      }
    }
    const serviceId = dbBooking ? dbBooking.service_id : "general";
    const durationMinutes = SERVICE_DURATIONS[serviceId] || 120;
    const durationMs = durationMinutes * 60 * 1e3;
    const bufferMs = 30 * 60 * 1e3;
    const endMs = startMs + durationMs + bufferMs;
    const newEndIso = new Date(endMs).toISOString();
    const newStartDate = new Date(newStart);
    const dayStartIso = new Date(Date.UTC(newStartDate.getFullYear(), newStartDate.getMonth(), newStartDate.getDate(), 0, 0, 0)).toISOString();
    const dayEndIso = new Date(Date.UTC(newStartDate.getFullYear(), newStartDate.getMonth(), newStartDate.getDate(), 23, 59, 59)).toISOString();
    const busyRanges = await getGoogleCalendarBusyRanges(dayStartIso, dayEndIso);
    const conflict = busyRanges.some((range) => {
      return startMs < range.end && endMs > range.start;
    });
    if (conflict) {
      return {
        statusCode: 409,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "The requested new date and time slot is unavailable. Please select another time window." })
      };
    }
    const calendarUpdated = await updateGoogleCalendarEventByBookingId(cleanBookingId, cleanEmail, newStart, newEndIso);
    if (!dbBooking && !calendarUpdated) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Booking ID not found. Please verify your booking ID and email." })
      };
    }
    if (dbBooking && SUPABASE_URL && SUPABASE_SERVICE_ROLE_KEY) {
      await fetch(`${SUPABASE_URL}/rest/v1/bookings?id=eq.${encodeURIComponent(cleanBookingId)}`, {
        method: "PATCH",
        headers: {
          "apikey": SUPABASE_SERVICE_ROLE_KEY,
          "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
          "Content-Type": "application/json",
          "Prefer": "return=minimal"
        },
        body: JSON.stringify({
          start_time: newStart,
          end_time: newEndIso,
          status: "rescheduled",
          updated_at: (/* @__PURE__ */ new Date()).toISOString()
        })
      }).catch((err) => console.error("Supabase reschedule update error:", err));
    }
    const custName = dbBooking ? dbBooking.customer_name : "Customer";
    const custPhone = dbBooking ? dbBooking.customer_phone : "N/A";
    const serviceName = dbBooking ? dbBooking.service_name : "Handyman Service";
    const formattedNewTime = new Date(newStart).toLocaleString("en-US", {
      timeZone: "America/New_York",
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit",
      hour12: true
    });
    fetch("https://api.web3forms.com/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        access_key: "5cd5e45a-9146-4c3a-ac2f-8b2904476cf0",
        subject: `\u{1F4C5} APPOINTMENT RESCHEDULED #${cleanBookingId}`,
        from_name: "Here Handyman Online Reschedule",
        message: `AN APPOINTMENT HAS BEEN RESCHEDULED ONLINE

Booking ID: ${cleanBookingId}
Customer: ${custName}
Phone: ${custPhone}
Email: ${cleanEmail}
Service: ${serviceName}
New Date & Time: ${formattedNewTime}
Google Calendar Updated: ${calendarUpdated ? "YES" : "NO/NOT FOUND"}`
      })
    }).catch((err) => console.error("Web3Forms reschedule email background error:", err));
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        success: true,
        bookingId: cleanBookingId,
        newStart,
        formattedTime: formattedNewTime,
        message: `Appointment ${cleanBookingId} has been successfully rescheduled for ${formattedNewTime}.`
      })
    };
  } catch (err) {
    console.error("Reschedule handler error:", err);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Internal server error during rescheduling." })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
