var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/book.js
var book_exports = {};
__export(book_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(book_exports);
var import_node_crypto2 = __toESM(require("crypto"), 1);

// netlify/functions/dbConfig.js
var DB_CONFIG = {
  SUPABASE_URL: process.env.SUPABASE_URL || "https://vvwnmiffuaxiazlskeya.supabase.co",
  SUPABASE_SERVICE_ROLE_KEY: process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY || "sb_publishable_-kxhroGZF03Y-RkyJ_bVTQ_5MQZRCZc"
};

// netlify/functions/googleCalendar.js
var import_node_crypto = __toESM(require("crypto"), 1);
var saProject = process.env.FIREBASE_PROJECT_ID || "handymanserviceadmin";
var GOOGLE_SA_EMAIL = process.env.GOOGLE_SA_EMAIL || `herehandyman-booking@${saProject}.iam.gserviceaccount.com`;
var GOOGLE_SA_PRIVATE_KEY = (process.env.GOOGLE_SA_PRIVATE_KEY || "").replace(/\\n/g, "\n");
var GOOGLE_CALENDAR_ID = process.env.GOOGLE_CALENDAR_ID || "davi65@gmail.com";
async function getAccessToken() {
  if (!GOOGLE_SA_EMAIL || !GOOGLE_SA_PRIVATE_KEY) {
    return null;
  }
  const now = Math.floor(Date.now() / 1e3);
  const header = { alg: "RS256", typ: "JWT" };
  const claimSet = {
    iss: GOOGLE_SA_EMAIL,
    scope: "https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/calendar.events",
    aud: "https://oauth2.googleapis.com/token",
    exp: now + 3600,
    iat: now
  };
  const b64Header = Buffer.from(JSON.stringify(header)).toString("base64url");
  const b64ClaimSet = Buffer.from(JSON.stringify(claimSet)).toString("base64url");
  const unsignedJwt = `${b64Header}.${b64ClaimSet}`;
  const signer = import_node_crypto.default.createSign("RSA-SHA256");
  signer.update(unsignedJwt);
  const signature = signer.sign(GOOGLE_SA_PRIVATE_KEY, "base64url");
  const jwt = `${unsignedJwt}.${signature}`;
  const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: jwt
    })
  });
  if (!tokenRes.ok) {
    const errorText = await tokenRes.text();
    console.error("Google OAuth token error:", errorText);
    return null;
  }
  const tokenData = await tokenRes.json();
  return tokenData.access_token;
}
async function getGoogleCalendarBusyRanges(dayStartIso, dayEndIso) {
  try {
    const token = await getAccessToken();
    if (!token || !GOOGLE_CALENDAR_ID) return [];
    const res = await fetch("https://www.googleapis.com/calendar/v3/freeBusy", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        timeMin: dayStartIso,
        timeMax: dayEndIso,
        timeZone: "America/New_York",
        items: [{ id: GOOGLE_CALENDAR_ID }]
      })
    });
    if (!res.ok) {
      console.error("Google FreeBusy error:", await res.text());
      return [];
    }
    const data = await res.json();
    const calendarData = data.calendars && data.calendars[GOOGLE_CALENDAR_ID];
    const busyList = calendarData ? calendarData.busy || [] : [];
    return busyList.map((item) => ({
      start: new Date(item.start).getTime(),
      end: new Date(item.end).getTime()
    }));
  } catch (err) {
    console.error("Error fetching Google Calendar busy ranges:", err);
    return [];
  }
}
async function createGoogleCalendarEvent({
  bookingId,
  startIso,
  endIso,
  serviceName,
  customerName,
  customerPhone,
  customerEmail,
  customerAddress,
  zip,
  notes
}) {
  try {
    const token = await getAccessToken();
    if (!token || !GOOGLE_CALENDAR_ID) return null;
    const eventPayload = {
      summary: `\u{1F528} [${bookingId}] ${serviceName} - ${customerName}`,
      location: `${customerAddress}, ZIP ${zip}`,
      description: `APPOINTMENT CONFIRMED FROM WEBSITE

Booking ID: ${bookingId}
Customer: ${customerName}
Phone: ${customerPhone}
Email: ${customerEmail || "Not provided"}
Address: ${customerAddress}, ZIP ${zip}
Service: ${serviceName}
Notes: ${notes || "None"}`,
      start: { dateTime: startIso, timeZone: "America/New_York" },
      end: { dateTime: endIso, timeZone: "America/New_York" },
      reminders: {
        useDefault: false,
        overrides: [
          { method: "popup", minutes: 120 },
          { method: "popup", minutes: 30 }
        ]
      }
    };
    const res = await fetch(`https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(GOOGLE_CALENDAR_ID)}/events`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(eventPayload)
    });
    if (!res.ok) {
      console.error("Google Calendar Event Insert Error:", await res.text());
      return null;
    }
    const eventData = await res.json();
    return eventData.id;
  } catch (err) {
    console.error("Error creating Google Calendar event:", err);
    return null;
  }
}

// netlify/functions/setmore.js
var import_node_https = __toESM(require("https"), 1);
var SETMORE_REFRESH_TOKEN = process.env.SETMORE_REFRESH_TOKEN || "r1/b9ac1e2a5bq66TP8pWitf0crZXjF9TkqIMqrpFr28gixe";
var DAVID_STAFF_KEY = "6df5336e-23d0-4bfc-94a7-12dfbb70416e";
var SETMORE_SERVICES = {
  drywall: "0d83598c-3ba8-4575-8c59-5e9731ad266b",
  painting: "0d83598c-3ba8-4575-8c59-5e9731ad266b",
  tv: "48dbf914-6bad-426a-baf6-0d8d2a5fb235",
  furniture: "48dbf914-6bad-426a-baf6-0d8d2a5fb235",
  assembly: "48dbf914-6bad-426a-baf6-0d8d2a5fb235",
  carpentry: "8d634355-c9e6-4f71-9255-d1a774fdff14",
  electrical: "8d634355-c9e6-4f71-9255-d1a774fdff14",
  fixtures: "8d634355-c9e6-4f71-9255-d1a774fdff14",
  plumbing: "8d634355-c9e6-4f71-9255-d1a774fdff14",
  general: "8d634355-c9e6-4f71-9255-d1a774fdff14"
};
var cachedToken = null;
var tokenExpiresAt = 0;
async function getSetmoreAccessToken() {
  const now = Date.now();
  if (cachedToken && tokenExpiresAt > now + 6e4) {
    return cachedToken;
  }
  return new Promise((resolve, reject) => {
    const url = `https://developer.setmore.com/api/v1/o/oauth2/token?refreshToken=${encodeURIComponent(SETMORE_REFRESH_TOKEN)}`;
    import_node_https.default.get(url, (res) => {
      let data = "";
      res.on("data", (chunk) => data += chunk);
      res.on("end", () => {
        try {
          const parsed = JSON.parse(data);
          if (parsed.response && parsed.data && parsed.data.token) {
            cachedToken = parsed.data.token.access_token;
            tokenExpiresAt = Date.now() + (parsed.data.token.expires_in || 7200) * 1e3;
            resolve(cachedToken);
          } else {
            reject(new Error(`Failed to refresh Setmore token: ${data}`));
          }
        } catch (e) {
          reject(e);
        }
      });
    }).on("error", reject);
  });
}
async function callSetmoreApi(path, method = "GET", postData = null) {
  const token = await getSetmoreAccessToken();
  return new Promise((resolve, reject) => {
    const options = {
      hostname: "developer.setmore.com",
      path,
      method,
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json"
      }
    };
    const req = import_node_https.default.request(options, (res) => {
      let body = "";
      res.on("data", (chunk) => body += chunk);
      res.on("end", () => {
        try {
          resolve(JSON.parse(body));
        } catch (e) {
          resolve({ raw: body, statusCode: res.statusCode });
        }
      });
    });
    req.on("error", reject);
    if (postData) {
      req.write(JSON.stringify(postData));
    }
    req.end();
  });
}
async function createOrGetSetmoreCustomer({ name, email, phone }) {
  try {
    const nameParts = (name || "Valued Customer").trim().split(" ");
    const firstName = nameParts[0] || "Valued";
    const lastName = nameParts.slice(1).join(" ") || "Customer";
    const res = await callSetmoreApi("/api/v1/bookingapi/customer/create", "POST", {
      first_name: firstName,
      last_name: lastName,
      email_id: email || "customer@herehandyman.com",
      cell_phone: (phone || "").replace(/\D/g, "")
    });
    if (res.response && res.data && res.data.customer && res.data.customer.key) {
      return res.data.customer.key;
    }
    return null;
  } catch (err) {
    console.error("Error creating Setmore customer:", err);
    return null;
  }
}
async function createSetmoreAppointment({ name, email, phone, startISO, endISO, serviceId, notes, address, zip }) {
  try {
    const customerKey = await createOrGetSetmoreCustomer({ name, email, phone });
    const serviceKey = SETMORE_SERVICES[serviceId] || SETMORE_SERVICES.general;
    const comment = `HereHandyman.com Booking | Address: ${address || "N/A"}, ZIP: ${zip || "N/A"} | Phone: ${phone || "N/A"} | Notes: ${notes || "None"}`;
    const apptData = {
      staff_key: DAVID_STAFF_KEY,
      service_key: serviceKey,
      customer_key: customerKey,
      start_time: startISO,
      end_time: endISO,
      comment
    };
    const result = await callSetmoreApi("/api/v1/bookingapi/appointment/create", "POST", apptData);
    console.log("Setmore appointment creation result:", JSON.stringify(result));
    return result;
  } catch (err) {
    console.error("Failed to create Setmore appointment:", err);
    return null;
  }
}

// netlify/functions/book.js
var SERVICE_DURATIONS = {
  tv: 60,
  furniture: 60,
  assembly: 60,
  drywall: 120,
  painting: 120,
  electrical: 60,
  fixtures: 60,
  plumbing: 60,
  general: 180
};
var ALLOWED_ZIPS = [
  "10601",
  "10603",
  "10604",
  "10605",
  "10606",
  "10607",
  "10583",
  "10528",
  "10577",
  "10580",
  "10573",
  "10538",
  "10543",
  "10504",
  "10514",
  "10506",
  "10536",
  "10549",
  "10570",
  "10510",
  "10562",
  "10591",
  "10533",
  "10522",
  "10706",
  "10530",
  "10502",
  "10523",
  "10595",
  "10708",
  "10707",
  "10709",
  "10803",
  "10801",
  "10804",
  "10805",
  "10701",
  "10703",
  "10704",
  "10705",
  "10710"
];
async function handler(event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method Not Allowed" }) };
  }
  try {
    let body;
    try {
      body = JSON.parse(event.body);
    } catch (parseErr) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Invalid JSON request body." })
      };
    }
    const { zip, serviceId, start, name, phone, address, email, notes } = body;
    if (!zip || !serviceId || !start || !name || !phone) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Missing required fields (zip, serviceId, start, name, phone)." })
      };
    }
    const durationMinutes = SERVICE_DURATIONS[serviceId];
    if (!durationMinutes) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Invalid or unsupported service ID." })
      };
    }
    const cleanZip = String(zip).trim();
    const isZipValid = /^\d{5}$/.test(cleanZip) && (cleanZip.startsWith("10") || cleanZip.startsWith("11") || ALLOWED_ZIPS.includes(cleanZip));
    if (!isZipValid) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "ZIP code is outside our Westchester County service area." })
      };
    }
    const startMs = new Date(start).getTime();
    if (isNaN(startMs)) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Invalid appointment date format." })
      };
    }
    if (startMs <= Date.now()) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Appointment date must be in the future." })
      };
    }
    const durationMs = durationMinutes * 60 * 1e3;
    const bufferMs = 30 * 60 * 1e3;
    const endMs = startMs + durationMs + bufferMs;
    const startTimeIso = new Date(startMs).toISOString();
    const endTimeIso = new Date(endMs).toISOString();
    const bookingRangeStr = `[${startTimeIso},${endTimeIso})`;
    const bookingId = "HH-" + import_node_crypto2.default.randomUUID().slice(0, 8).toUpperCase();
    try {
      const gBusy = await getGoogleCalendarBusyRanges(startTimeIso, endTimeIso);
      const isGoogleBusy = (gBusy || []).some((b) => startMs < b.end && b.start < endMs);
      if (isGoogleBusy) {
        return {
          statusCode: 409,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ error: "This time slot is no longer available. Please select a different time." })
        };
      }
    } catch (gCheckErr) {
      console.error("Google Calendar freebusy check warning:", gCheckErr);
    }
    await createGoogleCalendarEvent({
      bookingId,
      startIso: startTimeIso,
      endIso: endTimeIso,
      serviceName: serviceId,
      customerName: name,
      customerPhone: phone,
      customerEmail: email,
      customerAddress: address,
      zip: cleanZip,
      notes
    }).catch((gErr) => console.error("Google Calendar Event Creation Error:", gErr));
    createSetmoreAppointment({
      name,
      email,
      phone,
      startISO: startTimeIso,
      endISO: endTimeIso,
      serviceId,
      notes,
      address,
      zip: cleanZip
    }).catch((sErr) => console.error("Setmore API Sync Error:", sErr));
    const SUPABASE_URL = DB_CONFIG.SUPABASE_URL;
    const SUPABASE_SERVICE_ROLE_KEY = DB_CONFIG.SUPABASE_SERVICE_ROLE_KEY;
    if (SUPABASE_URL && SUPABASE_SERVICE_ROLE_KEY && !SUPABASE_URL.includes("YOUR_SUPABASE")) {
      try {
        await fetch(`${SUPABASE_URL}/rest/v1/bookings`, {
          method: "POST",
          headers: {
            "apikey": SUPABASE_SERVICE_ROLE_KEY,
            "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
            "Content-Type": "application/json",
            "Prefer": "return=minimal"
          },
          body: JSON.stringify({
            id: bookingId,
            booking_range: bookingRangeStr,
            start_time: startTimeIso,
            end_time: endTimeIso,
            service_id: serviceId,
            zip: cleanZip,
            customer_name: name,
            customer_phone: phone,
            customer_address: address || "",
            customer_email: email || "",
            notes: notes || "",
            status: "confirmed"
          })
        });
      } catch (dbErr) {
        console.error("Supabase DB log warning:", dbErr);
      }
    }
    fetch("https://api.web3forms.com/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        access_key: "5cd5e45a-9146-4c3a-ac2f-8b2904476cf0",
        subject: `\u26A1 NEW APPOINTMENT BOOKED #${bookingId}`,
        from_name: "Here Handyman Direct Booking",
        message: `NEW APPOINTMENT CONFIRMED!

Booking ID: ${bookingId}
Name: ${name}
Phone: ${phone}
Address: ${address}
ZIP: ${cleanZip}
Service: ${serviceId}
Start Time: ${startTimeIso}
Notes: ${notes || "None"}`
      })
    }).catch((err) => console.error("Web3Forms email background error:", err));
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        success: true,
        id: bookingId,
        start: startTimeIso,
        message: "Appointment confirmed!"
      })
    };
  } catch (err) {
    console.error("Booking handler error:", err);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Internal server error" })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
